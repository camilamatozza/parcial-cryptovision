# web/forms.py
from django import forms

MOTIVOS = [
    ("asesoramiento", "Asesoramiento"),
    ("compra-venta", "Compra / Venta"),
    ("billeteras", "Billeteras digitales"),
    ("otros", "Otros"),
]

class ContactForm(forms.Form):
    nombre = forms.CharField(
        label="Nombre completo",
        max_length=100,
        widget=forms.TextInput(attrs={"placeholder": "Tu nombre"})
    )
    email = forms.EmailField(
        label="Email",
        widget=forms.EmailInput(attrs={"placeholder": "tunombre@mail.com"})
    )
    motivo = forms.ChoiceField(
        label="Motivo",
        choices=MOTIVOS
    )
    mensaje = forms.CharField(
        label="Mensaje",
        widget=forms.Textarea(attrs={"rows": 4, "placeholder": "Contanos qué necesitás"})
    )
    acepta = forms.BooleanField(
        label="Acepto la política de privacidad"
    )
